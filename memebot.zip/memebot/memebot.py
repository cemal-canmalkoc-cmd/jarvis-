#!/usr/bin/env python3
"""
Meme-Coin Paper-Trading-Bot (Solana) – NUR SIMULATION, kein echtes Geld.

Strategie (so arbeiten die meisten gaengigen Meme-Coin-Bots im Kern):
  1. Scannen:   neue/trendende Solana-Tokens von DexScreener holen
  2. Filtern:   Scam-Check (RugCheck) + Mindest-Liquiditaet/Volumen/Alter
  3. Einstieg:  Momentum – Kurs steigt kurzfristig, mehr Kaeufe als Verkaeufe
  4. Ausstieg:  Take-Profit, Stop-Loss, Trailing-Stop, maximale Haltedauer
  5. Risiko:    fester Einsatz pro Trade, max. offene Positionen, Tagesverlust-Limit

Es gibt KEINE Gewinngarantie. Teste hier, ob die Strategie ueber Wochen
ueberhaupt profitabel ist, bevor du auch nur an echtes Geld denkst.

Start:
  python3 memebot.py            # live Kursdaten, Spielgeld
  python3 memebot.py --demo     # komplett offline mit zufaelligen Kursen (Logik-Test)
  python3 memebot.py --live     # ECHTER Handel ueber Jupiter (siehe live.py)
"""

import argparse
import json
import random
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, date

try:
    import requests
except ImportError:  # nur fuer --demo nicht noetig
    requests = None

# ----------------------------------------------------------------- Einstellungen
CONFIG = {
    "start_kapital_usd": 1000.0,
    "einsatz_pro_trade_usd": 25.0,     # fester Betrag, nie "alles rein"
    "max_offene_positionen": 5,
    "max_tagesverlust_usd": 100.0,     # danach stoppt der Bot fuer den Tag
    "take_profit_pct": 40.0,           # +40 % -> Gewinn mitnehmen
    "stop_loss_pct": -20.0,            # -20 % -> raus
    "trailing_stop_pct": 15.0,         # faellt 15 % vom Hoch -> raus
    "max_haltedauer_min": 60,
    "gebuehren_slippage_pct": 2.0,     # realistische Kosten pro Kauf UND Verkauf
    # Filter
    "min_liquiditaet_usd": 20_000,
    "min_volumen_1h_usd": 50_000,
    "min_alter_min": 10,               # ganz frische Tokens sind oft Rugs
    "max_alter_std": 24,
    "min_kurs_aenderung_5m_pct": 3.0,  # Momentum
    "min_kauf_verkauf_ratio": 1.3,
    "max_rugcheck_score": 1000,        # niedriger = sicherer
    "scan_intervall_sek": 3,           # alle 3 Sekunden scannen
    # Nur fuer --live (echtes Geld)
    "live_einsatz_sol": 0.05,          # pro Trade
    "live_max_einsatz_sol": 0.5,       # harte Obergrenze, egal was oben steht
    "live_slippage_bps": 1500,         # 15 % – Meme Coins schwanken stark
    "live_prioritaetsgebuehr_lamports": 200_000,  # ~0.0002 SOL, damit der Trade schnell durchgeht
    # Gewinne laufen lassen
    "einsatz_prozent": 0,              # >0: Einsatz = X % vom aktuellen Guthaben (waechst mit Gewinnen)
    "teilverkauf_bei_pct": 0,          # >0: bei +X % einen Teil verkaufen ...
    "teilverkauf_anteil": 0.5,         # ... diesen Anteil (0.5 = Haelfte), Rest laeuft weiter
}
# 0 bedeutet bei diesen Werten "unbegrenzt / aus":
#   max_offene_positionen, max_tagesverlust_usd, take_profit_pct, live_max_einsatz_sol, max_haltedauer_min

PROFILE = {
    "vorsichtig": {},
    # Maximales Gewinnpotenzial: unbegrenzt viele Coins, Gewinner laufen lassen.
    # Verluste koennen genauso gross werden!
    "aggressiv": {
        "max_offene_positionen": 0,        # unbegrenzt – kauft jeden Coin mit Potenzial
        "einsatz_prozent": 5,              # 5 % vom Guthaben pro Coin, waechst mit Gewinnen
        "live_max_einsatz_sol": 0,         # keine feste SOL-Obergrenze
        "take_profit_pct": 0,              # kein festes Gewinnziel ...
        "teilverkauf_bei_pct": 100,        # ... bei 2x die Haelfte verkaufen = Einsatz zurueck
        "teilverkauf_anteil": 0.5,
        "trailing_stop_pct": 25,           # Rest laeuft, bis er 25 % vom Hoch faellt
        "stop_loss_pct": -25,
        "max_haltedauer_min": 0,           # kein Zeitlimit
        "max_tagesverlust_usd": 300,       # Notbremse; 0 = aus
        "min_kurs_aenderung_5m_pct": 2.0,  # Filter etwas lockerer -> mehr Trades
        "min_kauf_verkauf_ratio": 1.2,
    },
}
SOL_MINT = "So11111111111111111111111111111111111111112"

DEX_PROFILES = "https://api.dexscreener.com/token-profiles/latest/v1"
DEX_BOOSTS = "https://api.dexscreener.com/token-boosts/latest/v1"
DEX_TOKENS = "https://api.dexscreener.com/tokens/v1/solana/{}"
RUGCHECK = "https://api.rugcheck.xyz/v1/tokens/{}/report/summary"
LOGFILE = "trades.jsonl"


# ----------------------------------------------------------------- Datenmodelle
@dataclass
class Position:
    mint: str
    symbol: str
    einstieg: float
    menge: float
    einsatz: float
    zeit: float = field(default_factory=time.time)
    hoch: float = 0.0
    sol: float = 0.0          # nur live: eingesetzte SOL
    teil_verkauft: bool = False

    def __post_init__(self):
        self.hoch = self.hoch or self.einstieg


@dataclass
class Konto:
    cash: float
    positionen: dict = field(default_factory=dict)
    tages_pnl: float = 0.0
    tag: date = field(default_factory=date.today)
    trades: int = 0
    gewinner: int = 0


# ----------------------------------------------------------------- Datenquellen
class LiveMarkt:
    def __init__(self):
        if requests is None:
            raise SystemExit("Bitte installieren: pip install requests")
        self.s = requests.Session()
        self.s.headers["User-Agent"] = "paper-trading-bot"

    def _get(self, url):
        try:
            r = self.s.get(url, timeout=10)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            print(f"  [Netz] {url[:60]}... -> {e}")
            return None

    def kandidaten(self):
        mints = []
        for url in (DEX_BOOSTS, DEX_PROFILES):
            for t in self._get(url) or []:
                if t.get("chainId") == "solana" and t.get("tokenAddress"):
                    mints.append(t["tokenAddress"])
        mints = list(dict.fromkeys(mints))[:30]
        return self.paare(mints)

    def paare(self, mints):
        """Bestes Handelspaar (hoechste Liquiditaet) je Token."""
        out = {}
        if not mints:
            return out
        data = self._get(DEX_TOKENS.format(",".join(mints))) or []
        for p in data:
            mint = p.get("baseToken", {}).get("address")
            liq = (p.get("liquidity") or {}).get("usd") or 0
            if mint and (mint not in out or liq > out[mint]["liq"]):
                tx = (p.get("txns") or {}).get("h1") or {}
                out[mint] = {
                    "mint": mint,
                    "symbol": p.get("baseToken", {}).get("symbol", "?"),
                    "preis": float(p.get("priceUsd") or 0),
                    "liq": liq,
                    "vol_1h": (p.get("volume") or {}).get("h1") or 0,
                    "chg_5m": (p.get("priceChange") or {}).get("m5") or 0,
                    "buys": tx.get("buys", 0),
                    "sells": tx.get("sells", 0),
                    "erstellt_ms": p.get("pairCreatedAt") or 0,
                }
        return out

    def sol_preis(self):
        p = self.paare([SOL_MINT]).get(SOL_MINT)
        return p["preis"] if p else None

    def rug_score(self, mint):
        d = self._get(RUGCHECK.format(mint))
        if not d:
            return None, ["RugCheck nicht erreichbar"]
        risiken = [r.get("name", "?") for r in d.get("risks", []) if r.get("level") == "danger"]
        return d.get("score", 99999), risiken


class DemoMarkt:
    """Offline-Simulation: zufaellige Tokens, viele davon Rugs – wie im echten Leben."""

    def __init__(self):
        self.tokens = {}
        self.n = 0

    def _neu(self):
        self.n += 1
        mint = f"DEMO{self.n:04d}"
        self.tokens[mint] = {
            "mint": mint, "symbol": f"MEME{self.n}", "preis": random.uniform(1e-5, 1e-2),
            "liq": random.uniform(5e3, 2e5), "vol_1h": random.uniform(1e4, 5e5),
            "chg_5m": 0.0, "buys": 0, "sells": 0,
            "erstellt_ms": (time.time() - random.uniform(300, 30000)) * 1000,
            "_rug": random.random() < 0.35, "_drift": random.gauss(0, 0.02),
        }

    def kandidaten(self):
        for _ in range(random.randint(0, 3)):
            self._neu()
        for t in self.tokens.values():
            alt = t["preis"]
            if t["_rug"] and random.random() < 0.08:
                t["preis"] *= 0.05          # Rug Pull: -95 %
                t["liq"] *= 0.05
            else:
                t["preis"] *= max(0.01, 1 + t["_drift"] + random.gauss(0, 0.08))
            t["chg_5m"] = (t["preis"] / alt - 1) * 100
            t["buys"] = random.randint(50, 400)
            t["sells"] = random.randint(50, 400)
        return dict(self.tokens)

    def paare(self, mints):
        return {m: self.tokens[m] for m in mints if m in self.tokens}

    def rug_score(self, mint):
        t = self.tokens[mint]
        # Der Checker erkennt nur ~70 % der Rugs – kein Filter ist perfekt
        if t["_rug"] and random.random() < 0.7:
            return 5000, ["Mint Authority aktiv", "Top-10 Holder > 60 %"]
        return random.randint(0, 800), []


# ----------------------------------------------------------------- Bot-Logik
class Bot:
    def __init__(self, markt, cfg, live=None):
        self.m = markt
        self.c = cfg
        self.live = live
        self.k = Konto(cash=cfg["start_kapital_usd"])
        self.geprueft = {}  # mint -> (ok, grund)

    def log(self, ereignis, **daten):
        daten.update(ereignis=ereignis, zeit=datetime.now().isoformat(timespec="seconds"))
        with open(LOGFILE, "a") as f:
            f.write(json.dumps(daten) + "\n")

    # --- Filter ---------------------------------------------------------
    def filter(self, t):
        c = self.c
        alter_min = (time.time() * 1000 - t["erstellt_ms"]) / 60000 if t["erstellt_ms"] else 0
        if t["preis"] <= 0:
            return False, "kein Preis"
        if t["liq"] < c["min_liquiditaet_usd"]:
            return False, f"Liquiditaet {t['liq']:.0f}$ zu gering"
        if t["vol_1h"] < c["min_volumen_1h_usd"]:
            return False, "Volumen zu gering"
        if not (c["min_alter_min"] <= alter_min <= c["max_alter_std"] * 60):
            return False, f"Alter {alter_min:.0f} min ausserhalb"
        if t["chg_5m"] < c["min_kurs_aenderung_5m_pct"]:
            return False, "kein Momentum"
        if t["buys"] < c["min_kauf_verkauf_ratio"] * max(t["sells"], 1):
            return False, "zu wenig Kaufdruck"
        # Teurer Check zuletzt und gecacht
        if t["mint"] not in self.geprueft:
            score, risiken = self.m.rug_score(t["mint"])
            ok = score is not None and score <= c["max_rugcheck_score"] and not risiken
            self.geprueft[t["mint"]] = (ok, f"RugCheck {score} {risiken}")
        ok, grund = self.geprueft[t["mint"]]
        return (True, "ok") if ok else (False, grund)

    # --- Handel ---------------------------------------------------------
    def kaufen(self, t):
        c = self.c
        einsatz = c["einsatz_pro_trade_usd"]
        if c["einsatz_prozent"] > 0:
            einsatz = self.k.cash * c["einsatz_prozent"] / 100
        if not self.live and (einsatz < 1 or self.k.cash < einsatz):
            return
        sol, sig = 0.0, None
        eff_preis = t["preis"] * (1 + c["gebuehren_slippage_pct"] / 100)
        if self.live:
            guthaben = self.live.sol_guthaben()
            sol = c["live_einsatz_sol"]
            if c["einsatz_prozent"] > 0:
                sol = (guthaben - 0.02) * c["einsatz_prozent"] / 100
            if c["live_max_einsatz_sol"] > 0:
                sol = min(sol, c["live_max_einsatz_sol"])
            sol_usd = self.m.sol_preis()
            if not sol_usd or sol < 0.005:
                return
            einsatz = sol * sol_usd
            if guthaben < sol + 0.02:  # Reserve fuer Gebuehren
                print("  Zu wenig SOL in der Bot-Wallet.")
                return
            t0 = time.time()
            try:
                sig, _ = self.live.kaufen(t["mint"], sol)
            except Exception as e:
                print(f"  KAUF FEHLGESCHLAGEN {t['symbol']}: {e}")
                return
            print(f"  (bestaetigt in {time.time() - t0:.1f}s) https://solscan.io/tx/{sig}")
            eff_preis = t["preis"]  # echte Kosten stecken in der SOL-Differenz
        pos = Position(t["mint"], t["symbol"], eff_preis, einsatz / eff_preis, einsatz, sol=sol)
        self.k.cash -= einsatz
        self.k.positionen[t["mint"]] = pos
        print(f"  KAUF  {t['symbol']:<10} {einsatz:.2f}$ @ {t['preis']:.8f}")
        self.log("kauf", mint=t["mint"], symbol=t["symbol"], preis=t["preis"], einsatz=round(einsatz, 2),
                 sol=sol, tx=sig)

    def verkaufen(self, pos, preis, grund, anteil=1.0):
        sig = None
        if self.live:
            try:
                sig, sol_zurueck = self.live.verkaufen_anteil(pos.mint, anteil)
            except Exception as e:
                print(f"  VERKAUF FEHLGESCHLAGEN {pos.symbol}: {e} – neuer Versuch naechste Runde")
                return
            sol_usd = self.m.sol_preis() or pos.einsatz / pos.sol
            erloes = sol_zurueck * sol_usd
            print(f"  https://solscan.io/tx/{sig}")
        else:
            erloes = pos.menge * anteil * preis * (1 - self.c["gebuehren_slippage_pct"] / 100)
        kosten = pos.einsatz * anteil
        pnl = erloes - kosten
        self.k.cash += erloes
        self.k.tages_pnl += pnl
        if anteil >= 1:
            del self.k.positionen[pos.mint]
            self.k.trades += 1
            # Gewinner = ganzer Trade inkl. frueherem Teilverkauf im Plus
            self.k.gewinner += pos.teil_verkauft or pnl > 0
        else:
            pos.menge *= 1 - anteil
            pos.einsatz -= kosten
            pos.sol *= 1 - anteil
            pos.teil_verkauft = True
        print(f"  VERK  {pos.symbol:<10} {grund:<12} {anteil * 100:.0f} %  PnL {pnl:+.2f}$ "
              f"({pnl / kosten * 100:+.1f} %)")
        self.log("verkauf", mint=pos.mint, symbol=pos.symbol, preis=preis, pnl=round(pnl, 2), grund=grund, tx=sig)

    def positionen_pruefen(self, kurse):
        c = self.c
        for pos in list(self.k.positionen.values()):
            t = kurse.get(pos.mint)
            if not t or t["preis"] <= 0:
                continue
            p = t["preis"]
            pos.hoch = max(pos.hoch, p)
            pct = (p / pos.einstieg - 1) * 100
            vom_hoch = (1 - p / pos.hoch) * 100
            dauer = (time.time() - pos.zeit) / 60
            if c["take_profit_pct"] > 0 and pct >= c["take_profit_pct"]:
                self.verkaufen(pos, p, "Take-Profit")
            elif c["teilverkauf_bei_pct"] > 0 and not pos.teil_verkauft and pct >= c["teilverkauf_bei_pct"]:
                self.verkaufen(pos, p, "Teilgewinn", c["teilverkauf_anteil"])
            elif pct <= c["stop_loss_pct"]:
                self.verkaufen(pos, p, "Stop-Loss")
            elif pct > 0 and vom_hoch >= c["trailing_stop_pct"]:
                self.verkaufen(pos, p, "Trailing")
            elif c["max_haltedauer_min"] > 0 and dauer >= c["max_haltedauer_min"]:
                self.verkaufen(pos, p, "Zeitlimit")

    def runde(self):
        if self.k.tag != date.today():
            self.k.tag, self.k.tages_pnl = date.today(), 0.0

        kurse = self.m.kandidaten()
        # Kurse offener Positionen nachladen, falls nicht mehr im Scan
        fehlend = [m for m in self.k.positionen if m not in kurse]
        kurse.update(self.m.paare(fehlend))
        self.positionen_pruefen(kurse)

        limit = self.c["max_tagesverlust_usd"]
        if limit > 0 and self.k.tages_pnl <= -limit:
            print("  Tagesverlust-Limit erreicht – keine neuen Kaeufe heute.")
            return
        for t in kurse.values():
            maxpos = self.c["max_offene_positionen"]
            if maxpos > 0 and len(self.k.positionen) >= maxpos:
                break
            if t["mint"] in self.k.positionen:
                continue
            ok, _ = self.filter(t)
            if ok:
                self.kaufen(t)

    def status(self, kurse=None):
        offen = sum(p.menge * p.einstieg for p in self.k.positionen.values())
        gesamt = self.k.cash + offen
        quote = self.k.gewinner / self.k.trades * 100 if self.k.trades else 0
        print(f"[{datetime.now():%H:%M:%S}] Konto ~{gesamt:.2f}$ | Cash {self.k.cash:.2f}$ | "
              f"offen {len(self.k.positionen)} | Trades {self.k.trades} | Trefferquote {quote:.0f} % | "
              f"Heute {self.k.tages_pnl:+.2f}$")


def main():
    ap = argparse.ArgumentParser(description="Meme-Coin Paper-Trading-Bot (Simulation)")
    ap.add_argument("--demo", action="store_true", help="offline mit Zufallskursen")
    ap.add_argument("--live", action="store_true", help="ECHTER Handel mit der Bot-Wallet")
    ap.add_argument("--profil", choices=PROFILE, default="vorsichtig",
                    help="vorsichtig (Standard) oder aggressiv (unbegrenzt viele Coins, Gewinne laufen lassen)")
    ap.add_argument("--runden", type=int, default=0, help="Anzahl Runden (0 = endlos)")
    args = ap.parse_args()

    cfg = dict(CONFIG)
    cfg.update(PROFILE[args.profil])
    print(f"Profil: {args.profil}")
    if args.demo:
        cfg["scan_intervall_sek"] = 0
        if cfg["max_haltedauer_min"] > 0:
            cfg["max_haltedauer_min"] = 0.001 * 40  # Demo: Zeitlimit nach ~40 Runden-Sekunden
    live = None
    if args.live:
        if args.demo:
            raise SystemExit("--live und --demo gehen nicht zusammen.")
        from live import LiveHandel
        live = LiveHandel(cfg)
        guthaben = live.sol_guthaben()
        print("!!! ECHTER HANDEL – du kannst dein gesamtes Guthaben in dieser Wallet verlieren !!!")
        print(f"Bot-Wallet: {live.pub}  Guthaben: {guthaben:.4f} SOL")
        einsatz = (f"{cfg['einsatz_prozent']} % vom Guthaben" if cfg["einsatz_prozent"] > 0
                   else f"{cfg['live_einsatz_sol']} SOL")
        print(f"Einsatz/Trade: {einsatz}, max. Positionen: {cfg['max_offene_positionen'] or 'unbegrenzt'}, "
              f"max. Tagesverlust: {cfg['max_tagesverlust_usd'] or 'AUS'} $")
        if input("Zum Starten 'JA' eingeben: ").strip() != "JA":
            raise SystemExit("Abgebrochen.")
    bot = Bot(DemoMarkt() if args.demo else LiveMarkt(), cfg, live)

    print("=== ECHTER HANDEL ===" if live else "=== PAPER TRADING – Spielgeld, keine echten Trades ===")
    i = 0
    try:
        while not args.runden or i < args.runden:
            i += 1
            bot.runde()
            if i % 10 == 0 or not args.demo:
                bot.status()
            time.sleep(cfg["scan_intervall_sek"] if not args.demo else 0.05)
    except KeyboardInterrupt:
        pass
    print("\n=== Ergebnis ===")
    bot.status()
    print(f"Alle Trades: {LOGFILE}")


if __name__ == "__main__":
    main()
